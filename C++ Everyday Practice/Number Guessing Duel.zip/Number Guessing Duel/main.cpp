#include <iostream>
#include "game.h"
using namespace std;

int main()
{
    game g1("Mike","Aries",42);

    while(!g1.isOver())
    {
        g1.playRound();
        g1.printScores();
    }



    return 0;
}
